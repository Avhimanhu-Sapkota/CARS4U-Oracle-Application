----------------------------VIEW FOR EACH TABLE---------------------------------

---------------------------------CUSTOMER TABLE---------------------------------
CREATE VIEW CUSTOMER_DETAILS AS 
    SELECT * FROM CUSTOMER;

---------------------------------CONTRACT TABLE---------------------------------
CREATE VIEW CONTRACT_DETAILS AS
    SELECT * FROM CONTRACT;

---------------------------------INSURANCE TABLE--------------------------------
CREATE VIEW INSURANCE_INFO AS 
    SELECT * FROM INSURANCE;
    
---------------------------HIRE_ARRANGEMENT TABLE-------------------------------
CREATE VIEW HIRE_ARRANGEMENT_INFO AS 
    SELECT * FROM HIRE_ARRANGEMENT;
   
------------------------------ACCESSORIES TABLE---------------------------------
CREATE VIEW ACCESSORY_DETAILS AS
    SELECT * FROM ACCESSORIES;
    
-------------------------------HIRE_INVOICE TABLE-------------------------------
CREATE VIEW HIRE_INVOICE_INFO AS
    SELECT * FROM HIRE_INVOICE;
  
-----------------------------VEHICLES TABLE-------------------------------------
CREATE VIEW VEHICLES_DETAILS AS
    SELECT * FROM VEHICLES;
    
------------------------------CENTER TABLE--------------------------------------
CREATE VIEW CENTER_DETAILS AS
    SELECT * FROM CENTER;
   
----------------------CENTER_CLASSIFICATION_PRICE TABLE-------------------------
CREATE VIEW PRICE_BASED_ON_CENTER_AND_CLASS AS
    SELECT * FROM CENTER_CLASSIFICATION_PRICE;
    
---------------------------VIEW TO TEST TABLES----------------------------------

------------------------PRICE_LIST_OF_THAMEL------------------------------------  
CREATE VIEW VEHICLE_PRICE_IN_THAMEL AS
    SELECT V.VEHICLE_NAME, CE.PRICE_PER_DATE
    FROM CENTER C, CENTER_CLASSIFICATION_PRICE CE, VEHICLES V
    WHERE C.CENTER_ID = CE.FK1_CENTER_ID
    AND V.VEHICLE_CLASS_SURR_ID = CE.FK2_VEHICLE_CLASS_SURR_ID
    AND C.CENTER_ADDRESS = 'Thamel, Kathmandu';
    
------------------------CUSTOMER_CONTRACT TYPE----------------------------------
CREATE VIEW CUSTOMER_CONTRACT_DETAILS AS
    SELECT CUSTOMER_ID, CUSTOMER_NAME, CONTRACT_TYPE, CONTRACT_DATE
    FROM CUSTOMER, CONTRACT
    WHERE CUSTOMER.CUSTOMER_ID = CONTRACT.FK1_CUSTOMER_ID;
    
----------------------CUSTOMER_INVOICE------------------------------------------
CREATE VIEW CUSTOMER_INVOICE AS
    SELECT C.CUSTOMER_NAME, H.HIRE_DATE, H.HIRE_NOOFDAYS, I.TOTAL_AMOUNT
    FROM CUSTOMER C, HIRE_ARRANGEMENT H, HIRE_INVOICE I
    WHERE C.CUSTOMER_ID = H.FK1_CUSTOMER_ID 
    AND H.HIRE_ID = I.FK1_HIRE_ID;
--------------------------------------------------------------------------------