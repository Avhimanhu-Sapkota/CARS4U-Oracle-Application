--------------------------------------INSERT INTO DML----------------------------------------------------

------------------------Insert values into ACCESSORIES table---------------------------------------------
INSERT INTO ACCESSORIES VALUES (3001,'Roof rack',3,'This is the carrier roof that vehicle needs', 800);
INSERT INTO ACCESSORIES VALUES (3002,'Baby seat',5,'This is an extrenal seat for baby', 500);
INSERT INTO ACCESSORIES VALUES (3003,'Car cover',20,'This is a cover that covers vehicle', 200);
INSERT INTO ACCESSORIES VALUES (3004,'Toolkit',20,'This helps in maintaining the vehicle', 500);
INSERT INTO ACCESSORIES VALUES (3005,'GPS Navigator',10,'This navigates user through the route', 1000);
---------------------------------------------------------------------------------------------------------

----------------Insert values into CENTER table---------------------------------
INSERT INTO CENTER VALUES (501,'Thamel, Kathmandu',015033043,446600);
INSERT INTO CENTER VALUES (502,'Siddharth, Pokhara',015033040,346600);
INSERT INTO CENTER VALUES (503,'Hetauda, Makwanpur',015033044,45600);
INSERT INTO CENTER VALUES (504,'Lumbini, Kapilvastu',015033045,349030);
INSERT INTO CENTER VALUES (505,'Dharan, Dhanusa',015033055,229320);
--------------------------------------------------------------------------------

-----------------------------Insert values into INSURANCE table-----------------------------------------
INSERT INTO INSURANCE VALUES (800,'No Policy','This is for corporate customers',0,0);
INSERT INTO INSURANCE VALUES (801,'Third Party','This benifits if someone else gets injured',50000,2);
INSERT INTO INSURANCE VALUES (802,'Vehicle','This benifits the vehicle',100000,2);
INSERT INTO INSURANCE VALUES (803,'Passenger','This benifits the passenger',50000,1);
INSERT INTO INSURANCE VALUES (804,'Full Package','This benifits everyone involved',200000,1);
--------------------------------------------------------------------------------------------------------

-------------------------------------------------Insert values into VEHICLES table--------------------------------------------------------------------------
INSERT INTO VEHICLES VALUES (901,2370,'Ford Fiesta 1.1',2013,5,'Hatchback','A car of ford. It is a hatchback whose ground clearance is high');
INSERT INTO VEHICLES VALUES (902,6623,'Fiat Panda',2010,5,'Hatchback','A car of Fiat. It is a hatchback good for city use');
INSERT INTO VEHICLES VALUES (903,7023,'Hyundai i20',2018,5,'Hatchback','A car of Hyundai. It is a hatchback that is good in highway');
INSERT INTO VEHICLES VALUES (904,2980,'Nissan Sunny',2017,4,'Saloon','A car of Nissan. It is a luxury sedan who’s good for business hire');
INSERT INTO VEHICLES VALUES (905,3790,'Honda City',2014,4,'Saloon','A car of Honda. It is a sedan which is luxurious in city');
INSERT INTO VEHICLES VALUES (906,6379,'Suzuki Swift D',2016,4,'Saloon','A car of Suzuki. It is a sedan which is good for family purposes');
INSERT INTO VEHICLES VALUES (907,2989,'Toyota Hilux',2015,6,'Pickup-truck','A car of Toyota. It is a pickup truck and has high power and more space');
INSERT INTO VEHICLES VALUES (908,6000,'Land Rover Discovery',2018,7,'SUV','It is a luxury adventure SUV which is good on off-road and on highway');
INSERT INTO VEHICLES VALUES (909,7093,'Toyota Prado',2018,7,'SUV','A car of Toyota. It is a SUV which is awesome for all purposes');
------------------------------------------------------------------------------------------------------------------------------------------------------------

-----Insert values into CENTER_CLASSIFICATION_PRICE table---------
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (201,2000,501,901);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (202,2200,501,902);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (203,1800,501,903);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (204,2500,501,904);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (205,2500,501,905);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (206,2200,501,906);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (207,4000,501,907);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (208,8000,501,908);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (209,8000,501,909);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (211,2300,502,901);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (212,2500,502,902);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (213,2100,502,903);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (214,2800,502,904);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (215,2800,502,905);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (216,2800,502,906);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (217,4500,502,907);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (218,8500,502,908);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (219,8500,502,909);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (221,2100,503,901);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (222,2300,503,902);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (223,2000,503,903);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (224,2700,503,904);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (225,2700,503,905);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (226,2700,503,906);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (227,4400,503,907);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (228,8600,503,908);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (229,8600,503,909);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (231,2200,504,901);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (232,2200,504,902);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (233,1900,504,903);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (234,2800,504,904);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (235,2800,504,905);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (236,2800,504,906);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (237,4300,504,907);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (238,8400,504,908);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (239,8400,504,909);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (241,2200,505,901);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (242,2400,505,902);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (243,2100,505,903);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (244,2800,505,904);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (245,2800,505,905);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (246,2800,505,906);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (247,4700,505,907);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (248,8800,505,908);
INSERT INTO CENTER_CLASSIFICATION_PRICE VALUES (249,8800,505,909);
-------------------------------------------------------------------

------------------------------------------Insert values into CUSTOMER table-----------------------------------------
INSERT INTO CUSTOMER VALUES (1001,'John Jensen','jjensen@gmail.com','Thamel, Kathmandu',9850232233,'',804);
INSERT INTO CUSTOMER VALUES (1002,'Rohit Raj Pandey','rrpandey@gmail.com','Chabahil, Kathmandu',9800232876,'',802);
INSERT INTO CUSTOMER VALUES (1003,'Anita Rijal','arijal@gmail.com','Ramkot, Pokhara',9723928322,'',804);
INSERT INTO CUSTOMER VALUES (1004,'Justin Gurung','jgurung@yahoo.com','Patan, Lalitpur',9854734120,'',801);
INSERT INTO CUSTOMER VALUES (1005,'Joey Foster','jfoster@gmail.com','Dharan, Dhanusa',9865402945,'',803);
INSERT INTO CUSTOMER VALUES (1006,'Nepal Bank','nepalbank@gmail.com','Tinkune, Kathmandu',014402323,'','800');
INSERT INTO CUSTOMER VALUES (1007,'Nepal Bank','nepalbank@gmail.com','Chabahil, Kathmandu',014402324,1006,'800');
INSERT INTO CUSTOMER VALUES (1008,'Nepal Bank','nepalbank@gmail.com','Thamel, Kathmandu',014402325,1006,'800');
----------------------------------------------------------------------------------------------------------------------

----------------Insert values into CONTRACT table-----------------
INSERT INTO CONTRACT VALUES (1,'Single',0,'10-10-2019',1001);
INSERT INTO CONTRACT VALUES (2, 'Single',0,'10-15-2019',1002);
INSERT INTO CONTRACT VALUES (3, 'Single',0,'10-23-2019',1003);
INSERT INTO CONTRACT VALUES (4, 'Single',0,'10-25-2019',1004);
INSERT INTO CONTRACT VALUES (5, 'Single',0,'10-28-2019',1005);
INSERT INTO CONTRACT VALUES (6,'Gold',50,'11-10-2019',1006);
INSERT INTO CONTRACT VALUES (7,'Silver',20,'11-11-2019',1007);
INSERT INTO CONTRACT VALUES (8,'Gold',50,'11-11-2019',1008);
-------------------------------------------------------------------

-----------Insert values into HIRE_ARRANGEMENT table---------------------
INSERT INTO HIRE_ARRANGEMENT VALUES (0001,'11-15-2019',5,1005,3001,234);
INSERT INTO HIRE_ARRANGEMENT VALUES (0002,'11-19-2019',2,1008,3003,206);
INSERT INTO HIRE_ARRANGEMENT VALUES (0003,'11-20-2019',3,1002,3001,208);
INSERT INTO HIRE_ARRANGEMENT VALUES (0004,'12-04-2019',3,1004,3004,244);
INSERT INTO HIRE_ARRANGEMENT VALUES (0005,'12-11-2019',6,1001,3001,228);
INSERT INTO HIRE_ARRANGEMENT VALUES (0006,'12-20-2019',3,1006,3001,244);
--------------------------------------------------------------------------

--------------Insert values into HIRE_INVOICE table----------------
INSERT INTO HIRE_INVOICE VALUES (5001,'11-20-2019',18000,'',0001);
INSERT INTO HIRE_INVOICE VALUES (5002,'11-21-2019',4800,'',0002);
INSERT INTO HIRE_INVOICE VALUES (5003,'11-23-2019',26400,'',0003);
INSERT INTO HIRE_INVOICE VALUES (5004,'12-07-2019',9900,'',0004);
INSERT INTO HIRE_INVOICE VALUES (5005,'12-17-2019',56400,'',0005);
INSERT INTO HIRE_INVOICE VALUES (5006,'12-23-2019',10800,'',0006);
--------------------------------------------------------------------