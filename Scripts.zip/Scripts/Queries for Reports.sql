--------------------------------------------REPORT QUERIES/VALIDATION QUESTIONS----------------------------------------------------------------

--Find vehicle name of saloon and hatchback classification.   
CREATE VIEW SALOON_AND_HATCHBACK AS
    SELECT VEHICLE_ID, VEHICLE_NAME
    FROM VEHICLES
    WHERE VEHICLE_CLASS IN ('Saloon', 'Hatchback');
-----------------------------------------------------------------------------------------------------------------------------------------------
    
--Display all the customers who hired vehicles in December 2019.
CREATE VIEW CUSTOMER_HIRE_DATE (CUSTOMER_ID, NAME, ADDRESS, HIRE_DATE) AS
    SELECT C.CUSTOMER_ID, C.CUSTOMER_NAME,C.CUSTOMER_ADDRESS, H.HIRE_DATE
    FROM CUSTOMER C, HIRE_ARRANGEMENT H 
    WHERE C.CUSTOMER_ID = H.FK1_CUSTOMER_ID
    AND H.HIRE_DATE BETWEEN '11-30-2019' AND '01-01-2020';
-----------------------------------------------------------------------------------------------------------------------------------------------
  
--Display details of customers who have hired accessory including accessory name and its description.
CREATE VIEW ACCESSORY_HIRE_DETAILS(CUSTOMER_ID, CUSTOMER_NAME, ACCESSORY, DESCRIPTION) AS
    SELECT C.CUSTOMER_ID, C.CUSTOMER_NAME, A.ACCESSORY_NAME, A.ACCESSORY_DESCRIPTION
    FROM CUSTOMER C, HIRE_ARRANGEMENT H, ACCESSORIES A
    WHERE C.CUSTOMER_ID = H.FK1_CUSTOMER_ID 
    AND H.FK2_ACCESSORY_ID = A.ACCESSORY_ID
    AND  H.FK2_ACCESSORY_ID IS NOT NULL;
    
--List center address, vehicle name and price of SUV in different CARS4U Centers using advance joins.
CREATE VIEW SUV_PRICE_LIST (CENTER_ADDRESS, NAME, PRICE_PER_DAY ) AS
    SELECT CE.CENTER_ADDRESS, V.VEHICLE_NAME, C.PRICE_PER_DATE
    FROM VEHICLES V
    LEFT JOIN CENTER_CLASSIFICATION_PRICE C 
        ON C.FK2_VEHICLE_CLASS_SURR_ID = V.VEHICLE_CLASS_SURR_ID
    LEFT JOIN CENTER CE 
        ON C.FK1_CENTER_ID = CE.CENTER_ID
    WHERE V.VEHICLE_CLASS = 'SUV';  
    
-----------------------------------------------------------------------------------------------------------------------------------------------
--Find the total amount for customer having name 'Nepal Bank'.
CREATE VIEW TOTAL_AMOUNT_NEPAL_BANK (TOTAL_AMOUNT_FOR_NEPAL_BANK) AS 
    SELECT SUM(I.TOTAL_AMOUNT)
    FROM CUSTOMER C, HIRE_ARRANGEMENT H, HIRE_INVOICE I
    WHERE  C.CUSTOMER_ID = H.FK1_CUSTOMER_ID
    AND H.HIRE_ID = I.FK1_HIRE_ID 
    AND C.CUSTOMER_NAME='Nepal Bank';  
    
-----------------------------------------------------------------------------------------------------------------------------------------------
--Display customers name, hire date, hire no of days and total amount which is more than 8000. Highest amount should be displayed first.
CREATE VIEW CUSTOMER_PRICE_LIST (CUSTOMER, HIRE_NO_OF_DAYS, HIRE_DATE, TOTAL_AMOUNT) AS
    SELECT C.CUSTOMER_NAME, H.HIRE_NOOFDAYS, H.HIRE_DATE, I.TOTAL_AMOUNT
    FROM CUSTOMER C, HIRE_ARRANGEMENT H, HIRE_INVOICE I
    WHERE C.CUSTOMER_ID = H.FK1_CUSTOMER_ID
    AND H.HIRE_ID = I.FK1_HIRE_ID
    AND I.TOTAL_AMOUNT > 8000
    ORDER BY I.TOTAL_AMOUNT DESC;     
-----------------------------------------------------------------------------------------------------------------------------------------------
      
    